from django.contrib import admin
from .models import Commande

admin.site.register(Commande)
